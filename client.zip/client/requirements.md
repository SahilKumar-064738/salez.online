## Packages
framer-motion | Complex animations for the demo flow and page transitions
lucide-react | Icon library
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Inter", "sans-serif"],
}
