import { api, buildUrl } from "@shared/routes";
import { API_BASE } from "@/lib/api";

export async function getConversations() {
  const res = await fetch(
    API_BASE + buildUrl(api.conversations.list.path),
    { credentials: "include" }
  );

  if (!res.ok) throw new Error("Failed to fetch conversations");
  return res.json();
}

export async function getConversation(id: string) {
  const res = await fetch(
    API_BASE + buildUrl(api.conversations.get.path, { id }),
    { credentials: "include" }
  );

  if (!res.ok) throw new Error("Conversation not found");
  return res.json();
}

export async function sendMessage(id: string, content: string) {
  const res = await fetch(
    API_BASE + buildUrl(api.conversations.sendMessage.path, { id }),
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ content }),
    }
  );

  if (!res.ok) throw new Error("Failed to send message");
  return res.json();
}
